export const Home = () => {

    return (
        <>
            <div className="home">
                <h1>Home</h1>
                <h3>Welcome to Cab booking System</h3>
                <h3>Go to Cab booking page and book the ride</h3>
            </div>
        </>
    );
};