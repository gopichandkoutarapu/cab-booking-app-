export const driverDataBase = [
    {
        firstName: "Deepak",
        lastName: "Singh",
        email: "test@mail.com",
        mobile: "1234567890",
        role: 'driver',
        availability: 'on',
        coordinates: {
            x: 1,
            y: 1
        }
    },
    {
        firstName: "Shyam",
        lastName: "Singh",
        email: "test@mail.com",
        mobile: "1234567890",
        role: 'driver',
        availability: 'on',
        coordinates: {
            x: 2,
            y: 4
        }
    },
    {
        firstName: "Abhishek",
        lastName: "Singh",
        email: "test@mail.com",
        mobile: "1234567890",
        role: 'driver',
        availability: 'on',
        coordinates: {
            x: 3,
            y: 5
        }
    },
    {
        firstName: "Shubham",
        lastName: "Singh",
        email: "test@mail.com",
        mobile: "1234567890",
        role: 'driver',
        availability: 'on',
        coordinates: {
            x: 7,
            y: 9
        }
    },
    {
        firstName: "Rajaan",
        lastName: "Singh",
        email: "test@mail.com",
        mobile: "1234567890",
        role: 'driver',
        availability: 'on',
        coordinates: {
            x: 9,
            y: 9
        }
    },
    {
        firstName: "Kartik",
        lastName: "Singh",
        email: "test@mail.com",
        mobile: "1234567890",
        role: 'driver',
        availability: 'on',
        coordinates: {
            x: 5,
            y: 5
        }
    },
]